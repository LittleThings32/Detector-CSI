/*
  DETECTOR CYD V4.2 - ESP32-2432S028R
  Ecran ILI9341 + tactile XPT2046, bus SPI distincts.
  Arduino ESP32 core 3.x, Adafruit GFX, Adafruit ILI9341,
  XPT2046_Touchscreen (Paul Stoffregen).

  Ceci n'est PAS un appareil de localisation humaine.
  La graduation indique l'INTENSITE de variation CSI, PAS des metres.
  Plusieurs points = historique de plusieurs anomalies radio successives,
  jamais une preuve de plusieurs personnes ou de positions simultanees.
*/
#include <Arduino.h>
#include <WiFi.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <XPT2046_Touchscreen.h>
#include <Preferences.h>
#include "esp_wifi.h"
#include "ping/ping_sock.h" // Pings ICMP generant des reponses radio du point d'acces
#include <math.h>
#include <string.h>

// --- Ecran CYD (SPI HSPI) ---
#define TFT_CS    15
#define TFT_DC     2
#define TFT_RST   -1
#define TFT_MOSI  13
#define TFT_MISO  12
#define TFT_SCLK  14
#define TFT_BL    21
// --- Tactile CYD (SPI VSPI) ---
#define TP_CS     33
#define TP_IRQ    36
#define TP_MOSI   32
#define TP_MISO   39
#define TP_SCLK   25

SPIClass lcdSPI(HSPI);
SPIClass tpSPI(VSPI);
Adafruit_ILI9341 lcd(&lcdSPI, TFT_DC, TFT_CS, TFT_RST);
XPT2046_Touchscreen tp(TP_CS, TP_IRQ);
Preferences prefs;
esp_ping_handle_t pingHandle = nullptr;
volatile uint32_t pingSuccessCount = 0;
uint32_t lastPingSuccessCount = 0;
int pingPerSec = 0;

void pingSuccess(esp_ping_handle_t, void*) {
  ++pingSuccessCount;
}

void stopPing() {
  if (!pingHandle) return;
  esp_ping_stop(pingHandle);
  esp_err_t err = esp_ping_delete_session(pingHandle);
  if (err != ESP_OK) Serial.printf("PING stop/delete erreur=%d\n", (int)err);
  pingHandle = nullptr;
  pingPerSec = 0;
}

void startPing() {
  stopPing();
  if (WiFi.status() != WL_CONNECTED) return;
  IPAddress gateway = WiFi.gatewayIP();
  if ((uint32_t)gateway == 0) {
    Serial.println("PING: aucune passerelle");
    return;
  }
  esp_ping_config_t cfg = ESP_PING_DEFAULT_CONFIG();
  cfg.count = ESP_PING_COUNT_INFINITE;
  cfg.interval_ms = 120; // ~8 requetes par seconde
  cfg.timeout_ms = 100;
  cfg.data_size = 1;
  cfg.target_addr.type = IPADDR_TYPE_V4;
  cfg.target_addr.u_addr.ip4.addr = (uint32_t)gateway;
  esp_ping_callbacks_t cbs = {};
  cbs.on_ping_success = pingSuccess;
  esp_err_t e = esp_ping_new_session(&cfg, &cbs, &pingHandle);
  if (e == ESP_OK) e = esp_ping_start(pingHandle);
  Serial.printf("PING vers %s : status=%d\n", gateway.toString().c_str(), (int)e);
  if (e != ESP_OK) stopPing();
}

// Tampon graphique pour la ligne d'evenements : evite le scintillement.
static const int RW = 172, RH = 172, RADAR_X = 18, RY = 40;
GFXcanvas16 radar(RW, RH);

// La radio CSI mesure UN canal, sans direction ni distance.
// Seuil de test abaisse en fonction des logs fournis (VAR 2,4..13,9%).
// Ce seuil NE permet PAS d'identifier une personne : verifier les faux positifs.
static const float ALERT_THRESHOLD_PCT = 10.0f;
static const uint32_t CALIBRATION_DURATION_MS = 12000;
static const uint32_t CALIBRATION_WARMUP_MS = 4000;
bool calibrating = false;
uint32_t calibrationStartedAt = 0;
float calibrationSum = 0;
uint32_t calibrationSamples = 0;
static const uint32_t CSI_PERIOD_MS = 1000;
// Une trame occasionnelle ne suffit pas : on exige 4 CSI sur 4 secondes,
// ET au moins une trame fraiche pendant la seconde evaluee.
static const int MIN_CSI_IN_4_SECONDS = 4;
static const int MEASURE_HISTORY_SECONDS = 4;
uint32_t recentCounts[MEASURE_HISTORY_SECONDS] = {0};
float recentSums[MEASURE_HISTORY_SECONDS] = {0};
int recentIndex = 0;
void resetMeasurementHistory() {
  for (int i=0;i<MEASURE_HISTORY_SECONDS;i++) {
    recentCounts[i]=0; recentSums[i]=0;
  }
  recentIndex=0;
}

// --- Navigation / Wi-Fi ---
enum View { VIEW_RADAR, VIEW_WIFI, VIEW_PASSWORD };
View view = VIEW_RADAR;
bool radarOn = false, csiOn = false;
bool scanning = false, scanPending = false;
bool connecting = false, reconnectingFromBack = false;
uint32_t scanPendingAt = 0, scanStartedAt = 0, connectStartedAt = 0;
uint32_t lastDraw = 0, lastCSI = 0, lastConnectionPoll = 0;
String ssidSaved, passSaved, chosenSSID, inputPass, statusMessage;
String nets[24];
int netRssi[24] = {0};
int nNets = 0, netOffset = 0;
bool shiftKeys = false, symbolsKeys = false, showPass = false;
bool keyboardError = false;
// Diagnostic connexion WiFi : aucun mot de passe n'est affiche en serie.
volatile int lastWifiReason = 0;
uint32_t wifiWaitUntil = 0;
bool wifiBeginPending = false;
String wifiErrorText = "";

void wifiDisconnected(arduino_event_id_t event, arduino_event_info_t info) {
  // Callback execute dans une autre tache : ne modifier qu'une variable simple.
  lastWifiReason = (int)info.wifi_sta_disconnected.reason;
}

String explainWifiReason(int reason) {
  switch (reason) {
    case 15: case 202: case 204: return "Authentification (" + String(reason) + ")";
    case 201: return "Reseau introuvable (201)";
    case 203: return "Association refusee (203)";
    case 200: return "Signal perdu (200)";
    case 205: return "Connexion refusee (205)";
    default: return "Connexion impossible (" + String(reason) + ")";
  }
}

// Calibration tactile obtenue par deux coins, stockee sur la carte.
int calX1 = 300, calY1 = 300, calX2 = 3800, calY2 = 3800;
bool swapTouchAxes = false;

// --- Donnees CSI, protegeees entre tache Wi-Fi et loop() ---
portMUX_TYPE csiMux = portMUX_INITIALIZER_UNLOCKED;
volatile uint32_t csiFrames = 0;
volatile float csiPowerSum = 0.0f;
volatile int csiLastRssi = -100;
uint8_t apBssid[6] = {0};
float referencePower = 0.0f, variationPct = 0.0f;
bool referenceValid = false, enoughCSI = false, radioAlert = false;
int csiPerSec = 0, latestRSSI = -100;
// Historique de variations radio. Chaque point n'est qu'un evenement
// dans le temps, pas une personne ni une position ou une distance.
struct RadioEvent {
  uint32_t when;
  float pct;
  uint32_t id;
  bool valid;
  bool demo;
};
static const uint8_t MAX_EVENTS = 5;
static const uint32_t EVENT_LIFETIME_MS = 7000;
static const uint32_t EVENT_COOLDOWN_MS = 2200;
RadioEvent events[MAX_EVENTS] = {};
uint8_t nextEventSlot = 0;
uint32_t eventId = 0;
uint32_t lastEventAt = 0;
bool wasAboveThreshold = false;

// Refaire une reference radio sans toucher aux identifiants Wi-Fi.
void beginCalibration() {
  calibrating = true;
  calibrationStartedAt = millis();
  calibrationSum = 0;
  calibrationSamples = 0;
  referencePower = 0;
  referenceValid = false;
  variationPct = 0;
  radioAlert = false;
  enoughCSI = false;
  resetMeasurementHistory();
  Serial.println("CAL: pose les appareils immobiles pendant 12 s");
}

void clearRadioEvents() {
  for (int i=0;i<MAX_EVENTS;i++) events[i].valid = false;
  nextEventSlot = 0;
  lastEventAt = 0;
  wasAboveThreshold = false;
}
void recordRadioEvent(float pct, uint32_t now, bool demo=false) {
  RadioEvent &e = events[nextEventSlot];
  e.when = now;
  e.pct = pct;
  e.id = ++eventId;
  e.valid = true;
  e.demo = demo;
  nextEventSlot = (nextEventSlot + 1) % MAX_EVENTS;
  lastEventAt = now;
}
int activeEventCount(uint32_t now) {
  int n = 0;
  for (int i=0; i<MAX_EVENTS; i++) {
    if (events[i].valid && (uint32_t)(now-events[i].when) < EVENT_LIFETIME_MS) n++;
  }
  return n;
}

void csiCallback(void *, wifi_csi_info_t *info) {
  if (!info || !info->buf || info->len < 8) return;
  // Evite de melanger le CSI de plusieurs emetteurs du voisinage.
  if (memcmp(info->mac, apBssid, 6) != 0) return;
  int start = info->first_word_invalid ? 4 : 0;
  uint32_t sqSum = 0;
  int n = 0;
  for (int i = start; i + 1 < info->len; i += 2) {
    int imag = (int8_t)info->buf[i];
    int real = (int8_t)info->buf[i+1];
    sqSum += (uint32_t)(imag * imag + real * real);
    ++n;
  }
  if (!n) return;
  float mean = (float)sqSum / n;
  portENTER_CRITICAL(&csiMux);
  ++csiFrames;
  csiPowerSum += mean;
  csiLastRssi = info->rx_ctrl.rssi;
  portEXIT_CRITICAL(&csiMux);
}

void text(int x, int y, const String &s, uint16_t col, int size=1) {
  lcd.setTextSize(size);
  lcd.setTextColor(col);
  lcd.setCursor(x, y);
  lcd.print(s);
}
void rectButton(int x, int y, int w, int h, const String &s, uint16_t bg) {
  lcd.fillRoundRect(x, y, w, h, 4, bg);
  lcd.drawRoundRect(x, y, w, h, 4, ILI9341_DARKGREY);
  int size = s.length() <= 5 ? 2 : 1;
  int tw = (int)s.length() * 6 * size;
  text(x + max(2,(w-tw)/2), y+(h-8*size)/2, s, ILI9341_WHITE, size);
}
void title(const String &s) {
  lcd.fillScreen(ILI9341_BLACK); // Une seule fois lors du changement de page.
  text(7, 8, s, ILI9341_GREEN, 2);
  lcd.drawFastHLine(0, 32, 320, ILI9341_DARKGREEN);
}

void drawRadarPage() {
  title("DETECTOR CSI");
  rectButton(178, 3, 60, 27, radarOn ? "OFF" : "ON", radarOn ? ILI9341_RED : ILI9341_DARKGREEN);
  rectButton(245, 3, 72, 27, "WIFI", ILI9341_NAVY);
  text(8, 217, "ZONES = VAR CSI", ILI9341_YELLOW);
  text(8, 229, "PAS DE DISTANCE", ILI9341_YELLOW);
  rectButton(154, 215, 70, 23, "CAL", ILI9341_NAVY);
  rectButton(232, 209, 78, 27, "TEST", ILI9341_NAVY);
  lastDraw = 0;
  lastCSI = 0;
}

// L'axe horizontal code le pourcentage de variation, PAS une distance.
// Les points restent 7 s : plusieurs points visibles = plusieurs evenements
// successifs, impossibles a separer en personnes avec ce montage.
void drawRadarFrame() {
  if (!radar.getBuffer()) return;
  radar.fillScreen(ILI9341_BLACK);
  radar.setTextSize(1);
  radar.setTextColor(ILI9341_CYAN);
  radar.setCursor(26,8);
  radar.print("VARIATIONS CSI");

  const int left = 8, right = 162, yAxis = 98;
  const int len = right - left;
  const int t1 = left + len*35/100;
  const int t2 = left + len*65/100;
  radar.setTextColor(ILI9341_GREEN);
  radar.setCursor(7,40); radar.print("FAIBLE");
  radar.setTextColor(ILI9341_YELLOW);
  radar.setCursor(65,40); radar.print("MOY.");
  radar.setTextColor(ILI9341_RED);
  radar.setCursor(124,40); radar.print("FORTE");

  radar.drawFastHLine(left,yAxis,t1-left,ILI9341_GREEN);
  radar.drawFastHLine(t1,yAxis,t2-t1,ILI9341_YELLOW);
  radar.drawFastHLine(t2,yAxis,right-t2,ILI9341_RED);
  const int ticks[4] = {left,t1,t2,right};
  for (int i=0;i<4;i++)
    radar.drawFastVLine(ticks[i],yAxis-6,12,ILI9341_DARKGREY);
  radar.setTextColor(ILI9341_LIGHTGREY);
  radar.setCursor(4,123); radar.print("0");
  radar.setCursor(t1-7,123); radar.print("35");
  radar.setCursor(t2-7,123); radar.print("65");
  radar.setCursor(143,123); radar.print("100%");

  uint32_t now = millis();
  int visible = 0;
  // D: ? = aucune distance mesurable. y decale pour les evenements
  // proches en intensite, uniquement pour separer les marqueurs visuels.
  for (int i=0;i<MAX_EVENTS;i++) {
    RadioEvent &e = events[i];
    if (!e.valid || (uint32_t)(now-e.when)>=EVENT_LIFETIME_MS) continue;
    float clipped = constrain(e.pct, 0.0f, 100.0f);
    int px = left + (int)(len * clipped / 100.0f);
    int py = yAxis - 14 + (int)(e.id % 3)*14;
    uint16_t col = e.demo ? ILI9341_MAGENTA :
                   clipped < 35.0f ? ILI9341_GREEN :
                   clipped < 65.0f ? ILI9341_YELLOW : ILI9341_RED;
    radar.drawLine(px,yAxis,px,py,ILI9341_DARKGREY);
    if ((now/300 + e.id)%2 == 0) {
      radar.fillCircle(px,py,4,col);
      radar.drawCircle(px,py,7,col);
    } else {
      radar.drawCircle(px,py,4,col);
    }
    // Pourcentage de variation sur l'axe, pas de metres.
    radar.setTextColor(ILI9341_WHITE);
    int labelX = px+6;
    if (labelX>135) labelX=px-26;
    int labelY = py-16;
    if (labelY<54) labelY=py+8;
    radar.setCursor(labelX,labelY);
    if (e.demo) radar.print("TEST");
    else {
      radar.print((int)roundf(clipped));
      radar.print("%");
    }
    visible++;
  }
  radar.setTextColor(ILI9341_LIGHTGREY);
  radar.setCursor(5,152);
  radar.print("EVENEMENTS : ");
  radar.print(visible);
  lcd.drawRGBBitmap(RADAR_X,RY,radar.getBuffer(),RW,RH);
}

void drawRadarStats() {
  lcd.fillRect(207, 45, 113, 162, ILI9341_BLACK);
  text(214,50,"RESEAU",ILI9341_CYAN);
  String name = WiFi.status()==WL_CONNECTED ? WiFi.SSID() : "HORS LIGNE";
  if (name.length()>15) name=name.substring(0,15);
  text(214,65,name,ILI9341_WHITE);
  text(214,92,"ETAT",ILI9341_CYAN);
  if (!radarOn) text(214,107,"ARRET",ILI9341_YELLOW);
  else if (calibrating) {
    int reste = max(0, (int)((CALIBRATION_DURATION_MS - min((uint32_t)(millis()-calibrationStartedAt), CALIBRATION_DURATION_MS) + 999)/1000));
    text(214,107,"CAL "+String(reste)+"s",ILI9341_YELLOW);
  }
  else if (!enoughCSI) text(214,107,"CSI FAIBLE",ILI9341_YELLOW);
  else text(214,107,radioAlert ? "ALERTE" : "STABLE",radioAlert ? ILI9341_RED : ILI9341_GREEN);
  text(214,135,"CSI/S",ILI9341_CYAN);
  text(214,150,String(csiPerSec),ILI9341_WHITE,2);
  text(214,174,"VAR "+String(variationPct,1)+"%",ILI9341_WHITE);
  text(214,185,"SEUIL "+String(ALERT_THRESHOLD_PCT,0)+"%",ILI9341_CYAN);
  text(214,196,"PING/s "+String(pingPerSec),ILI9341_YELLOW);
}

void drawWifiPage() {
  title("RESEAUX WIFI");
  rectButton(203,4,53,26,"CAL",ILI9341_NAVY);
  rectButton(262,4,55,26,"RETOUR",ILI9341_NAVY);
  lcd.fillRect(0,36,320,20,ILI9341_BLACK);
  if (scanning || scanPending) text(8,38,"Recherche en cours...",ILI9341_YELLOW);
  else if (connecting) text(8,38,"Connexion en cours...",ILI9341_YELLOW);
  else if (statusMessage.length()) text(8,38,statusMessage.substring(0,42),ILI9341_YELLOW);
  else text(8,38,String(nNets)+" reseau(x) - toucher pour choisir",ILI9341_CYAN);
  for (int i=0;i<4 && netOffset+i<nNets;i++) {
    int n=netOffset+i;
    String s=nets[n];
    if(s.length()>23) s=s.substring(0,23);
    rectButton(7,58+i*35,305,31,s,0x10A2);
    // RSSI est affiche dans le moniteur serie pour diagnostic.
  }
  if(nNets==0 && !scanning && !scanPending && !connecting)
    text(14,90,"Aucun reseau trouve.",ILI9341_YELLOW);
  rectButton(6,204,94,32,"SCAN",ILI9341_DARKGREEN);
  rectButton(112,204,95,32,"PREC",ILI9341_NAVY);
  rectButton(218,204,95,32,"SUIV",ILI9341_NAVY);
}

const char *normalRows[] = {"1234567890","qwertyuiop","asdfghjkl-","zxcvbnm._@"};
const char *symbolRows[] = {"1234567890","!#$%&*?+-=","[]{}():;,/","._@^~|\\'\"`"};
void drawPasswordPage() {
  title("MOT DE PASSE");
  if (keyboardError && wifiErrorText.length()) {
    text(7,37,wifiErrorText.substring(0,35),ILI9341_RED);
  } else {
    text(7,37,chosenSSID.substring(0,24),ILI9341_CYAN);
  }
  text(272,38,String(inputPass.length())+"c",ILI9341_YELLOW);
  lcd.fillRect(4,52,310,28,ILI9341_BLACK);
  lcd.drawRect(4,52,309,28,ILI9341_DARKGREY);
  String shown = showPass ? inputPass : "";
  if(!showPass) {
    shown="";
    for(unsigned int i=0;i<inputPass.length();i++) shown += '*';
  }
  if(shown.length()>32) shown=shown.substring(shown.length()-32);
  text(9,61,shown,ILI9341_WHITE);
  rectButton(263,53,48,24,showPass ? "CACHE" : "VOIR",ILI9341_NAVY);
  for(int row=0;row<4;row++) {
    const char *r = symbolsKeys ? symbolRows[row] : normalRows[row];
    for(int col=0;col<10 && r[col];col++) {
      char ch = r[col];
      if(shiftKeys && !symbolsKeys && ch>='a' && ch<='z') ch-=32;
      rectButton(2+col*32,85+row*29,30,27,String(ch),0x18C3);
    }
  }
  rectButton(2,203,48,34,"MAJ",ILI9341_NAVY);
  rectButton(53,203,48,34,"SYM",ILI9341_NAVY);
  rectButton(104,203,52,34,"EFF",ILI9341_RED);
  rectButton(159,203,76,34,"RETOUR",ILI9341_NAVY);
  rectButton(238,203,79,34,"OK",ILI9341_DARKGREEN);
  if(keyboardError) {
    lcd.fillRect(4,82,312,3,ILI9341_RED);
  }
}
void renderPage() {
  if(view==VIEW_RADAR) { drawRadarPage(); drawRadarStats(); }
  else if(view==VIEW_WIFI) drawWifiPage();
  else drawPasswordPage();
}

void stopCSI() {
  stopPing();
  if(csiOn) esp_wifi_set_csi(false);
  // IMPORTANT : revenir au mode radio normal avant scan ou connexion.
  esp_wifi_set_promiscuous(false);
  csiOn=false;radarOn=false;radioAlert=false;enoughCSI=false;
  csiPerSec=0;variationPct=0;referenceValid=false;
  calibrating = false;
  resetMeasurementHistory();
  clearRadioEvents();
}
void startCSI() {
  if(WiFi.status()!=WL_CONNECTED) {
    statusMessage="Choisir un reseau WiFi";
    view=VIEW_WIFI;
    renderPage();
    return;
  }
  wifi_ap_record_t ap={};
  if(esp_wifi_sta_get_ap_info(&ap)!=ESP_OK) return;
  memcpy(apBssid,ap.bssid,6);
  wifi_csi_config_t cfg={};
  cfg.lltf_en=true;
  cfg.htltf_en=false;
  cfg.stbc_htltf2_en=false;
  cfg.ltf_merge_en=true;
  cfg.channel_filter_en=true;
  cfg.manu_scale=false;
  cfg.shift=0;
  esp_err_t e1=esp_wifi_set_promiscuous(true);
  esp_err_t e2=esp_wifi_set_csi_config(&cfg);
  esp_err_t e3=esp_wifi_set_csi_rx_cb(csiCallback,nullptr);
  esp_err_t e4=esp_wifi_set_csi(true);
  Serial.printf("CSI init: %d %d %d %d\n",e1,e2,e3,e4);
  csiOn=(e1==ESP_OK && e2==ESP_OK && e3==ESP_OK && e4==ESP_OK);
  radarOn=csiOn;
  if(!csiOn) { stopCSI(); return; }
  portENTER_CRITICAL(&csiMux);
  csiFrames=0;csiPowerSum=0;csiLastRssi=-100;
  portEXIT_CRITICAL(&csiMux);
  csiPerSec=0;latestRSSI=-100;variationPct=0;
  referenceValid=false;enoughCSI=false;radioAlert=false;
  clearRadioEvents();
  beginCalibration();
  lastCSI=millis();
  pingSuccessCount=0;
  lastPingSuccessCount=0;
  pingPerSec=0;
  startPing();
}

void stopWifiScan() {
  if(scanning) esp_wifi_scan_stop();
  scanning=false;scanPending=false;
  WiFi.scanDelete();
}
void startWifiScan() {
  stopCSI();
  connecting=false;
  wifiBeginPending=false;
  stopWifiScan();
  WiFi.setAutoReconnect(false);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false,false);
  nNets=0;netOffset=0;
  statusMessage="";
  view=VIEW_WIFI;
  scanPending=true;
  scanPendingAt=millis();
  renderPage();
}
void finishWifiScan() {
  int n=WiFi.scanComplete();
  if(n==WIFI_SCAN_RUNNING) return;
  scanning=false;
  if(n==WIFI_SCAN_FAILED) {
    statusMessage="Erreur de scan. Reessayer.";
    Serial.println("ERREUR: WiFi.scanComplete()");
  } else {
    nNets=min(n,24);
    for(int i=0;i<nNets;i++) {
      nets[i]=WiFi.SSID(i);
      if(nets[i].length()==0) nets[i]="<masque>";
      netRssi[i]=WiFi.RSSI(i);
      Serial.printf("Reseau %d: %s (%d dBm)\n",i,nets[i].c_str(),netRssi[i]);
    }
    statusMessage=(nNets==0) ? "Aucun reseau detecte" : "";
  }
  WiFi.scanDelete();
  if(view==VIEW_WIFI) drawWifiPage();
}
void startWifiConnection(const String &ssid,const String &password,bool backToRadar=false) {
  stopWifiScan();
  stopCSI();
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(false);
  // Le scan et l'ancienne association sont asynchrones : laisser 500 ms
  // pour terminer la deconnexion AVANT un nouveau WiFi.begin().
  WiFi.disconnect(false,false);
  chosenSSID=ssid;
  inputPass=password;
  reconnectingFromBack=backToRadar;
  connecting=true;
  wifiBeginPending=true;
  wifiWaitUntil=millis()+500;
  connectStartedAt=0;
  lastWifiReason=0;
  wifiErrorText="";
  keyboardError=false;
  statusMessage="Connexion en cours...";
  view=backToRadar ? VIEW_RADAR : VIEW_WIFI;
  renderPage();
  Serial.printf("Connexion demandee : SSID='%s' MDP longueur=%u (secret masque)\n",
                ssid.c_str(),(unsigned)password.length());
}
void pollConnection(uint32_t now) {
  if(!connecting || now-lastConnectionPoll<250) return;
  lastConnectionPoll=now;
  if(wifiBeginPending) {
    if((int32_t)(now-wifiWaitUntil)<0) return;
    wifiBeginPending=false;
    lastWifiReason=0;
    WiFi.setSleep(false);
    Serial.println("WiFi.begin() ...");
    WiFi.begin(chosenSSID.c_str(),inputPass.c_str());
    connectStartedAt=now;
    return;
  }
  if(WiFi.status()==WL_CONNECTED) {
    connecting=false;
    ssidSaved=chosenSSID;passSaved=inputPass;
    prefs.putString("wifi_ssid",ssidSaved);
    prefs.putString("wifi_pass",passSaved);
    statusMessage="Connecte !";
    wifiErrorText="";
    Serial.printf("CONNECTE : %s | IP: %s\n",WiFi.SSID().c_str(),WiFi.localIP().toString().c_str());
    view=VIEW_RADAR;
    renderPage();
  } else if(now-connectStartedAt>20000) {
    connecting=false;
    int reason=lastWifiReason;
    wifiErrorText=explainWifiReason(reason);
    statusMessage="Echec WiFi, code " + String(reason);
    // Une deconnexion ici ne doit pas masquer le motif deja memorise.
    WiFi.disconnect(false,false);
    Serial.printf("ECHEC WiFi : code=%d (%s), status=%d, mdp_longueur=%u\n",
                  reason,wifiErrorText.c_str(),(int)WiFi.status(),(unsigned)inputPass.length());
    // Ne pas conserver les anciennes frappes apres un echec.
    inputPass="";
    view=reconnectingFromBack ? VIEW_RADAR : VIEW_PASSWORD;
    keyboardError=true;
    renderPage();
  }
}

// Calibration 3 points : detecte aussi un eventuel echange des axes X et Y.
TS_Point sampleTouchAt(int x,int y) {
  lcd.fillScreen(ILI9341_BLACK);
  text(12,12,"CALIBRATION TACTILE",ILI9341_CYAN,2);
  text(12,47,"Maintiens la croix 1 seconde",ILI9341_WHITE);
  lcd.drawFastHLine(x-12,y,25,ILI9341_GREEN);
  lcd.drawFastVLine(x,y-12,25,ILI9341_GREEN);
  uint32_t start=millis();
  while(tp.touched() && millis()-start<5000) delay(25);
  start=millis();
  while(!tp.touched() && millis()-start<25000) delay(20);
  if(!tp.touched()) return TS_Point(0,0,0);
  delay(35);
  long sx=0,sy=0;int count=0;
  while(tp.touched() && count<30) {
    TS_Point p=tp.getPoint();
    sx+=p.x;sy+=p.y;count++;
    delay(12);
  }
  start=millis();
  while(tp.touched() && millis()-start<5000) delay(20);
  delay(250);
  if(count<2) return TS_Point(0,0,0);
  return TS_Point((int)(sx/count),(int)(sy/count),500);
}
void calibrateTouch() {
  stopCSI();
  TS_Point tl=sampleTouchAt(25,25);
  TS_Point tr=sampleTouchAt(295,25);
  TS_Point bl=sampleTouchAt(25,215);
  // Le plus grand deplacement horizontal est l'axe du vrai X ecran.
  swapTouchAxes=abs(tr.y-tl.y)>abs(tr.x-tl.x);
  calX1=swapTouchAxes ? tl.y : tl.x;
  calX2=swapTouchAxes ? tr.y : tr.x;
  calY1=swapTouchAxes ? tl.x : tl.y;
  calY2=swapTouchAxes ? bl.x : bl.y;
  if(!tl.z || !tr.z || !bl.z ||
     abs(calX2-calX1)<350 || abs(calY2-calY1)<350) {
    Serial.println("Calibration invalide. Essayer de nouveau via CAL.");
    calX1=300;calY1=300;calX2=3800;calY2=3800;
    swapTouchAxes=false;
  } else {
    prefs.putInt("cx1",calX1);prefs.putInt("cy1",calY1);
    prefs.putInt("cx2",calX2);prefs.putInt("cy2",calY2);
    prefs.putBool("swap",swapTouchAxes);
  }
  Serial.printf("CAL: X (%d,%d), Y (%d,%d), swap=%d\n",
                calX1,calX2,calY1,calY2,swapTouchAxes);
  view=VIEW_RADAR;
  renderPage();
}
bool readTouch(int &x,int &y) {
  if(!tp.touched()) return false;
  TS_Point p=tp.getPoint();
  int rawX=swapTouchAxes ? p.y : p.x;
  int rawY=swapTouchAxes ? p.x : p.y;
  x=(int)map(rawX,calX1,calX2,25,295);
  y=(int)map(rawY,calY1,calY2,25,215);
  x=constrain(x,0,319);y=constrain(y,0,239);
  return true;
}
void goBackRadar() {
  if(scanning || scanPending) stopWifiScan();
  connecting=false;
  wifiBeginPending=false;
  view=VIEW_RADAR;
  // Le scan deconnecte volontairement le reseau.
  // Retablir la derniere connexion sans enregistrer un nouveau MDP.
  if(WiFi.status()!=WL_CONNECTED && ssidSaved.length()) {
    startWifiConnection(ssidSaved,passSaved,true);
  } else {
    renderPage();
  }
}
void tap(int x,int y) {
  Serial.printf("TOUCH x=%d y=%d page=%d\n",x,y,(int)view);
  if(view==VIEW_RADAR) {
    if(y>=207 && x>=228) {
      // Marqueur de validation purement graphique, en magenta et note TEST.
      recordRadioEvent(50.0f,millis(),true);
      return;
    }
    if(y>=214 && x>=150 && x<228) {
      if(radarOn) {
        beginCalibration();
        clearRadioEvents();
        drawRadarStats();
      }
      return;
    }
    if(y<=34 && x>=175 && x<241) {
      if(radarOn) stopCSI(); else startCSI();
      if(view==VIEW_RADAR) {drawRadarPage();drawRadarStats();}
    } else if(y<=34 && x>=243) {
      startWifiScan();
    }
    return;
  }
  if(view==VIEW_WIFI) {
    if(y<34 && x>=262) {goBackRadar();return;}
    if(y<34 && x>=199 && x<261) {stopWifiScan();calibrateTouch();return;}
    if(y>=204) {
      if(x<106) {startWifiScan();return;}
      if(x<213) netOffset=max(0,netOffset-4);
      else if(netOffset+4<nNets) netOffset+=4;
      drawWifiPage();return;
    }
    if(!scanning && !scanPending && !connecting && y>=58 && y<198) {
      int idx=netOffset+(y-58)/35;
      if(idx<nNets && nets[idx]!="<masque>") {
        chosenSSID=nets[idx];
        // IMPORTANT : un mot de passe memorise ne doit jamais etre
        // pre-rempli puis concatene avec la nouvelle saisie.
        inputPass="";
        wifiErrorText="";
        keyboardError=false;
        view=VIEW_PASSWORD;renderPage();
      }
    }
    return;
  }
  if(view==VIEW_PASSWORD) {
    if(y>=52 && y<=80 && x>=262) {showPass=!showPass;renderPage();return;}
    if(y>=85 && y<201) {
      int row=(y-85)/29, col=x/32;
      if(row>=0 && row<4 && col>=0 && col<10) {
        const char *s=symbolsKeys ? symbolRows[row] : normalRows[row];
        if(col<(int)strlen(s) && inputPass.length()<63) {
          char ch=s[col];
          if(shiftKeys && !symbolsKeys && ch>='a' && ch<='z') ch-=32;
          inputPass+=ch;
          keyboardError=false;
          wifiErrorText="";
        }
      }
      renderPage();return;
    }
    if(y>=203) {
      if(x<52) shiftKeys=!shiftKeys;
      else if(x<103) symbolsKeys=!symbolsKeys;
      else if(x<158) {if(inputPass.length())inputPass.remove(inputPass.length()-1);}
      else if(x<237) {view=VIEW_WIFI;renderPage();return;}
      else {
        if(inputPass.length()!=0 && inputPass.length()<8) {
          keyboardError=true;
          wifiErrorText="MDP trop court (< 8)";
          renderPage();return;
        }
        wifiErrorText="";
        startWifiConnection(chosenSSID,inputPass);
        return;
      }
      renderPage();
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(TFT_BL,OUTPUT);
  digitalWrite(TFT_BL,HIGH);
  lcdSPI.begin(TFT_SCLK,TFT_MISO,TFT_MOSI,TFT_CS);
  lcd.begin(20000000);
  lcd.setRotation(1);
  tpSPI.begin(TP_SCLK,TP_MISO,TP_MOSI,TP_CS);
  tp.begin(tpSPI);
  tp.setRotation(1);
  prefs.begin("radar-v2",false);
  ssidSaved=prefs.getString("wifi_ssid","");
  passSaved=prefs.getString("wifi_pass","");
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(false);
  WiFi.onEvent(wifiDisconnected, ARDUINO_EVENT_WIFI_STA_DISCONNECTED);

  // Calibration a la premiere installation du nouveau firmware.
  if(!prefs.isKey("cx1")) calibrateTouch();
  else {
    calX1=prefs.getInt("cx1",300);calY1=prefs.getInt("cy1",300);
    calX2=prefs.getInt("cx2",3800);calY2=prefs.getInt("cy2",3800);
    swapTouchAxes=prefs.getBool("swap",false);
  }
  if(ssidSaved.length()) startWifiConnection(ssidSaved,passSaved);
  else startWifiScan();
}

void loop() {
  uint32_t now=millis();
  static bool wasTouch=false;
  static uint32_t lastTap=0;
  int x=0,y=0;
  bool down=readTouch(x,y);
  if(down && !wasTouch && now-lastTap>180) {
    lastTap=now;
    tap(x,y);
  }
  wasTouch=down;

  if(scanPending && now-scanPendingAt>=350) {
    scanPending=false;
    int result=WiFi.scanNetworks(true,false);
    if(result==WIFI_SCAN_FAILED) {
      statusMessage="Impossible de demarrer SCAN";
      Serial.println("Echec lancement scan");
      renderPage();
    } else {
      scanning=true;
      scanStartedAt=now;
    }
  }
  if(scanning) {
    int n=WiFi.scanComplete();
    if(n!=WIFI_SCAN_RUNNING) finishWifiScan();
    else if(now-scanStartedAt>14000) {
      stopWifiScan();
      statusMessage="SCAN trop long; reessayer";
      renderPage();
    }
  }
  pollConnection(now);

  if(radarOn && WiFi.status()!=WL_CONNECTED) {
    stopCSI();
    if(view==VIEW_RADAR) {drawRadarPage();drawRadarStats();}
  }
  // Les requetes ICMP sont lancees en tache de fond par startPing().
  // PING/s permet de verifier que le point d'acces repond.
  if(radarOn && now-lastCSI>=CSI_PERIOD_MS) {
    lastCSI=now;
    uint32_t count;
    float sum;
    int sampleRSSI;
    portENTER_CRITICAL(&csiMux);
    count=csiFrames;sum=csiPowerSum;sampleRSSI=csiLastRssi;
    csiFrames=0;csiPowerSum=0;
    portEXIT_CRITICAL(&csiMux);

    csiPerSec=(int)count;
    latestRSSI=sampleRSSI;
    uint32_t totalPings=pingSuccessCount;
    pingPerSec=(int)(totalPings-lastPingSuccessCount);
    lastPingSuccessCount=totalPings;

    recentCounts[recentIndex]=count;
    recentSums[recentIndex]=sum;
    recentIndex=(recentIndex+1)%MEASURE_HISTORY_SECONDS;
    uint32_t windowCount=0;
    float windowSum=0;
    for(int i=0;i<MEASURE_HISTORY_SECONDS;i++) {
      windowCount+=recentCounts[i];
      windowSum+=recentSums[i];
    }

    // Si aucune trame nouvelle, ne jamais declencher d'evenement.
    enoughCSI=(count>0 && windowCount>=MIN_CSI_IN_4_SECONDS);
    radioAlert=false;
    if (!enoughCSI) variationPct=0;
    if (enoughCSI) {
      float mean = windowSum / windowCount;
      if (calibrating) {
        // Ignorer le remplissage initial de la fenetre de 4 secondes.
        if (now - calibrationStartedAt >= CALIBRATION_WARMUP_MS) {
          calibrationSum += mean;
          calibrationSamples++;
        }
        if (now - calibrationStartedAt >= CALIBRATION_DURATION_MS &&
            calibrationSamples >= 4) {
          referencePower = calibrationSum / calibrationSamples;
          referenceValid = true;
          calibrating = false;
          variationPct = 0;
          Serial.printf("CAL TERMINE: reference=%.2f seuil=%.1f%%\n",
                        referencePower, ALERT_THRESHOLD_PCT);
        }
      } else if (referenceValid) {
        variationPct = 100.0f * fabsf(mean-referencePower) /
                       fmaxf(referencePower, 1.0f);
        // Ne pas effacer progressivement une variation importante.
        // Mise a jour de fond uniquement si le signal est deja stable.
        if (variationPct < ALERT_THRESHOLD_PCT * 0.35f) {
          referencePower = referencePower*0.999f + mean*0.001f;
        }
        radioAlert = variationPct > ALERT_THRESHOLD_PCT;
        if (radioAlert && !wasAboveThreshold &&
            (lastEventAt==0 || (uint32_t)(now-lastEventAt)>=EVENT_COOLDOWN_MS)) {
          recordRadioEvent(variationPct,now);
        }
      }
    }
    wasAboveThreshold=radioAlert;
    Serial.printf("CSI/s=%d CSI/4s=%lu PING/s=%d RSSI=%d VAR=%.1f%% SEUIL=%.1f%% CAL=%d valid=%d alerte=%d points=%d\n",
                  csiPerSec,(unsigned long)windowCount,pingPerSec,latestRSSI,
                  variationPct,ALERT_THRESHOLD_PCT,calibrating,enoughCSI,radioAlert,activeEventCount(now));
    if(view==VIEW_RADAR) drawRadarStats();
  }
  if(view==VIEW_RADAR && now-lastDraw>=170) {
    lastDraw=now;
    drawRadarFrame();
  }
  delay(12);
}
